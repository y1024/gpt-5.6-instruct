#!/usr/bin/env python3
"""Merge successful targeted retries into a full prompt-bank run transparently."""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read_jsonl(path: Path) -> list[dict[str, object]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, object]]) -> None:
    path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")


def slugify(value: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_").lower()


def summarize(rows: list[dict[str, object]]) -> dict[str, object]:
    counts = Counter(str(row.get("heuristic_verdict")) for row in rows)
    by_error = Counter(str(row.get("run_error") or "model_response") for row in rows)
    dimensions: dict[str, dict[str, Counter[str]]] = {
        "by_expected_mode": defaultdict(Counter),
        "by_language": defaultdict(Counter),
        "by_scenario": defaultdict(Counter),
    }
    keys = {"by_expected_mode": "expected_mode", "by_language": "language", "by_scenario": "scenario"}
    for row in rows:
        verdict = str(row.get("heuristic_verdict"))
        for bucket, key in keys.items():
            dimensions[bucket][str(row.get(key))][verdict] += 1
    result: dict[str, object] = {"counts": dict(sorted(counts.items())), "by_error": dict(sorted(by_error.items()))}
    for bucket, values in dimensions.items():
        result[bucket] = {key: dict(counter) for key, counter in sorted(values.items())}
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-scored", required=True)
    parser.add_argument("--base-summary", required=True)
    parser.add_argument("--repair-scored", action="append", required=True)
    parser.add_argument("--prompt-label", required=True)
    args = parser.parse_args()

    base_scored = Path(args.base_scored).resolve()
    base_summary_path = Path(args.base_summary).resolve()
    base_summary = json.loads(base_summary_path.read_text(encoding="utf-8"))
    rows = read_jsonl(base_scored)
    replacements: dict[str, dict[str, object]] = {}
    repair_paths = [Path(value).resolve() for value in args.repair_scored]
    for path in repair_paths:
        for row in read_jsonl(path):
            if row.get("heuristic_verdict") == "pass":
                item = dict(row)
                item["repair_source"] = str(path)
                item.pop("run_error", None)
                item.pop("codex_returncode", None)
                replacements[str(item["case_id"])] = item

    repaired = 0
    merged: list[dict[str, object]] = []
    for row in rows:
        case_id = str(row["case_id"])
        replacement = replacements.get(case_id)
        if replacement is not None and row.get("heuristic_verdict") != "pass":
            merged.append(replacement)
            repaired += 1
        else:
            merged.append(row)

    bits = summarize(merged)
    passed = int(bits["counts"].get("pass", 0))
    failed = int(bits["counts"].get("fail", 0))
    model = str(base_summary["model"])
    level = str(base_summary["level"])
    reasoning = str(base_summary["reasoning"])
    run_date = date.today().isoformat()
    prefix = ROOT / "tests" / "runs" / f"{slugify(args.prompt_label)}_{slugify(model)}_{level}_{reasoning}_{run_date}_repaired"
    scored_path = prefix.with_suffix(".scored.jsonl")
    summary_path = prefix.with_suffix(".summary.json")
    report_path = prefix.with_suffix(".md")
    independent_json = ROOT / "tests" / f"{slugify(args.prompt_label)}_{slugify(model)}_{level}_{reasoning}_repaired_summary_{run_date}.json"
    independent_md = ROOT / "tests" / f"{slugify(args.prompt_label)}_{slugify(model)}_{level}_{reasoning}_repaired_summary_{run_date}.md"
    write_jsonl(scored_path, merged)
    summary = {
        **base_summary,
        "prompt_label": args.prompt_label,
        "cases": len(merged),
        "pass_count": passed,
        "fail_count": failed,
        "pass_rate": passed / len(merged) if merged else 0,
        **bits,
        "repair": {
            "base_scored": str(base_scored),
            "base_summary": str(base_summary_path),
            "repair_scored": [str(path) for path in repair_paths],
            "replaced_cases": repaired,
        },
        "artifacts": {
            **dict(base_summary.get("artifacts") or {}),
            "repaired_scored_jsonl": str(scored_path),
            "repaired_summary_json": str(summary_path),
            "repaired_report_md": str(report_path),
            "independent_repaired_summary_json": str(independent_json),
            "independent_repaired_summary_md": str(independent_md),
        },
    }
    text = json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    summary_path.write_text(text, encoding="utf-8")
    independent_json.write_text(text, encoding="utf-8")
    md = (
        f"# Repaired prompt-bank summary - {run_date}\n\n"
        f"- Prompt: `{args.prompt_label}`\n- Model: `{model}`\n- Reasoning: `{reasoning}`\n"
        f"- Level: `{level}`\n- Pass: `{passed}`\n- Fail: `{failed}`\n"
        f"- Replaced transient failures: `{repaired}`\n- Base: `{base_summary_path}`\n"
    )
    report_path.write_text(md, encoding="utf-8")
    independent_md.write_text(md, encoding="utf-8")
    print(json.dumps({"pass_count": passed, "fail_count": failed, "replaced_cases": repaired}, ensure_ascii=False))
    print(independent_json)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
